CUHK Iris Image Dataset
Date of Generation: 13 March 2003
Authored by: CHUN, Chun Nam Ben (e-mail: cnchun@acae.cuhk.edu.hk)
Copyright: Computer Vision Laboratory,
                Department of Automation & Computer-Aided Engr.,
                The Chinese University of Hong Kong, Hong Kong
Important: The dataset can be freely used for
                non-profit making education or research purpose
                provided that the source of
                the dataset is cited fully;
                any other use however must first obtain prior
                agreement from the
                Computer Vision Laboratory,
                Department of Automation & Computer-Aided Engr.,
                The Chinese University of Hong Kong, Hong Kong.
Contact: Prof Chung, Chi Kit Ronald
                (e-mail: rchung@acae.cuhk.edu.hk;
                Tel: (852)26098339, Fax: (852)26036002)